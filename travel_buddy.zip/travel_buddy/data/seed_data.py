"""
seed_data.py
------------
Populates the database with realistic sample data so the app is usable
immediately after installation: 30 users, 80 trips, 200 buddy requests,
plus reviews and notifications.

Run directly with:
    python -m data.seed_data
"""

import random
import sys
import os
from datetime import date, timedelta

# Ensure project root is importable when running this file directly.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from faker import Faker

from database.database import init_db, get_session
from database.models import User, Trip, BuddyRequest, Review, Notification
from auth.hash import hash_password

fake = Faker()

DESTINATIONS = [
    "Paris", "London", "New York", "Tokyo", "Rome", "Bali", "Dubai", "Sydney",
    "Bangkok", "Barcelona", "Singapore", "Amsterdam", "Goa", "Mumbai", "Delhi",
    "Hyderabad", "Bangalore", "Cape Town", "Istanbul", "Rio de Janeiro",
    "Los Angeles", "San Francisco", "Berlin", "Seoul", "Kathmandu",
]

INTERESTS_POOL = [
    "hiking", "photography", "food", "nightlife", "museums", "beaches",
    "adventure sports", "shopping", "history", "nature", "yoga", "diving",
    "trekking", "wildlife", "culture", "music festivals",
]

LANGUAGES_POOL = ["English", "Spanish", "French", "German", "Hindi", "Mandarin", "Japanese", "Arabic"]

TRAVEL_STYLES = ["Adventure", "Luxury", "Solo", "Backpacking", "Foodie", "Photography"]

TRANSPORT_MODES = ["Flight", "Train", "Road Trip", "Cruise"]


def seed_users(count: int = 30) -> list:
    """Create sample users and return their ids."""
    user_ids = []
    with get_session() as session:
        for _ in range(count):
            name = fake.name()
            user = User(
                name=name,
                email=fake.unique.email(),
                password=hash_password("Password123"),
                phone=fake.msisdn()[:12],
                gender=random.choice(["Male", "Female", "Other"]),
                age=random.randint(19, 55),
                bio=fake.sentence(nb_words=15),
                city=fake.city(),
                country=fake.country(),
                profile_photo=None,
                languages=", ".join(random.sample(LANGUAGES_POOL, k=random.randint(1, 3))),
                interests=", ".join(random.sample(INTERESTS_POOL, k=random.randint(2, 5))),
                travel_style=random.choice(TRAVEL_STYLES),
                budget_preference=random.choice(["Low", "Medium", "High"]),
                verified=random.choice([True, False]),
                is_admin=False,
            )
            session.add(user)
            session.flush()
            user_ids.append(user.id)

        # Create one guaranteed admin account for demo purposes.
        admin = User(
            name="Admin User",
            email="admin@travelbuddy.com",
            password=hash_password("Admin@123"),
            phone="9999999999",
            gender="Other",
            age=30,
            bio="Platform administrator.",
            city="Hyderabad",
            country="India",
            interests="",
            languages="English",
            travel_style="",
            budget_preference="Medium",
            verified=True,
            is_admin=True,
        )
        session.add(admin)
        session.flush()
        user_ids.append(admin.id)

    return user_ids


def seed_trips(user_ids: list, count: int = 80) -> list:
    """Create sample trips and return their ids."""
    trip_ids = []
    with get_session() as session:
        for _ in range(count):
            start = date.today() + timedelta(days=random.randint(-30, 180))
            end = start + timedelta(days=random.randint(2, 14))
            trip = Trip(
                user_id=random.choice(user_ids),
                source=fake.city(),
                destination=random.choice(DESTINATIONS),
                start_date=start,
                end_date=end,
                budget=round(random.uniform(300, 5000), 2),
                transportation=random.choice(TRANSPORT_MODES),
                travel_style=random.choice(TRAVEL_STYLES),
                purpose=random.choice(["Leisure", "Adventure", "Business + Leisure", "Backpacking"]),
                description=fake.sentence(nb_words=20),
                max_companions=random.randint(1, 4),
            )
            session.add(trip)
            session.flush()
            trip_ids.append(trip.id)
    return trip_ids


def seed_buddy_requests(user_ids: list, trip_ids: list, count: int = 200) -> None:
    """Create sample buddy requests."""
    with get_session() as session:
        for _ in range(count):
            sender, receiver = random.sample(user_ids, 2)
            request = BuddyRequest(
                sender=sender,
                receiver=receiver,
                trip_id=random.choice(trip_ids) if trip_ids else None,
                status=random.choice(["pending", "accepted", "rejected"]),
            )
            session.add(request)


def seed_reviews(user_ids: list, count: int = 60) -> None:
    """Create sample reviews."""
    with get_session() as session:
        for _ in range(count):
            reviewer, reviewee = random.sample(user_ids, 2)
            review = Review(
                reviewer=reviewer,
                reviewee=reviewee,
                rating=random.randint(3, 5),
                review=fake.sentence(nb_words=12),
            )
            session.add(review)


def seed_notifications(user_ids: list, count: int = 60) -> None:
    """Create sample notifications."""
    templates = [
        ("New Buddy Request", "Someone wants to travel with you!"),
        ("Trip Reminder", "Your upcoming trip is approaching."),
        ("Request Accepted", "Your buddy request was accepted."),
        ("New Review", "You received a new review."),
    ]
    with get_session() as session:
        for _ in range(count):
            title, desc = random.choice(templates)
            note = Notification(
                user_id=random.choice(user_ids),
                title=title,
                description=desc,
                status=random.choice(["read", "unread"]),
            )
            session.add(note)


def run_seed() -> None:
    """Entry point: initialize the database and populate it with sample data."""
    print("Initializing database...")
    init_db()

    with get_session() as session:
        existing_users = session.query(User).count()
    if existing_users > 0:
        print(f"Database already has {existing_users} users. Skipping seed to avoid duplicates.")
        return

    print("Seeding users...")
    user_ids = seed_users(30)
    print(f"Created {len(user_ids)} users (including 1 admin: admin@travelbuddy.com / Admin@123)")

    print("Seeding trips...")
    trip_ids = seed_trips(user_ids, 80)
    print(f"Created {len(trip_ids)} trips")

    print("Seeding buddy requests...")
    seed_buddy_requests(user_ids, trip_ids, 200)
    print("Created 200 buddy requests")

    print("Seeding reviews...")
    seed_reviews(user_ids, 60)
    print("Created 60 reviews")

    print("Seeding notifications...")
    seed_notifications(user_ids, 60)
    print("Created 60 notifications")

    print("\nSeeding complete! Demo login: admin@travelbuddy.com / Admin@123")
    print("All sample users share the password: Password123")


if __name__ == "__main__":
    run_seed()
