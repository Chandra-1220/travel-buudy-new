"""
database.py
------------
Handles the SQLAlchemy engine, session factory, and database initialization
for the Travel Buddy Finder application.
"""

import os
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, Session
from contextlib import contextmanager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Resolve the database path relative to the project root so it works
# regardless of the current working directory the app is launched from.
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.path.join(BASE_DIR, "database.db")
DATABASE_URL = f"sqlite:///{DB_PATH}"

# `check_same_thread=False` is required because Streamlit may access the
# session from different threads across reruns.
engine = create_engine(
    DATABASE_URL,
    echo=False,
    connect_args={"check_same_thread": False},
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db() -> None:
    """
    Create all database tables if they do not already exist.

    This imports models lazily to avoid circular imports between
    database.py and models.py.
    """
    from database.models import Base

    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database initialized successfully at %s", DB_PATH)
    except Exception as exc:
        logger.exception("Failed to initialize database: %s", exc)
        raise


@contextmanager
def get_session():
    """
    Provide a transactional scope around a series of database operations.

    Usage:
        with get_session() as session:
            session.query(...)

    Yields:
        Session: A SQLAlchemy session object.
    """
    session: Session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()
