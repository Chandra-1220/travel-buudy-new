"""
crud.py
-------
Centralized Create / Read / Update / Delete operations for every model.
Keeping this logic separate from the Streamlit pages enforces a clean
separation between the UI layer and the data-access layer.
"""

import logging
from datetime import date, datetime
from typing import List, Optional

from sqlalchemy import or_, and_

from database.database import get_session
from database.models import (
    User,
    Trip,
    BuddyRequest,
    Message,
    Review,
    Wishlist,
    Notification,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# USER CRUD
# ---------------------------------------------------------------------------

def create_user(**kwargs) -> Optional[int]:
    """Create a new user record. Returns the new user's id, or None on failure."""
    with get_session() as session:
        user = User(**kwargs)
        session.add(user)
        session.flush()
        return user.id


def get_user_by_email(email: str) -> Optional[User]:
    """Fetch a single user by their email address."""
    with get_session() as session:
        user = session.query(User).filter(User.email == email.lower().strip()).first()
        session.expunge_all()
        return user


def get_user_by_id(user_id: int) -> Optional[User]:
    """Fetch a single user by primary key."""
    with get_session() as session:
        user = session.query(User).filter(User.id == user_id).first()
        session.expunge_all()
        return user


def get_all_users(exclude_id: Optional[int] = None) -> List[User]:
    """Return every user, optionally excluding a given user id (e.g. self)."""
    with get_session() as session:
        query = session.query(User)
        if exclude_id is not None:
            query = query.filter(User.id != exclude_id)
        users = query.all()
        session.expunge_all()
        return users


def update_user(user_id: int, **kwargs) -> bool:
    """Update fields on an existing user record."""
    with get_session() as session:
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            return False
        for key, value in kwargs.items():
            if hasattr(user, key) and value is not None:
                setattr(user, key, value)
        return True


def delete_user(user_id: int) -> bool:
    """Delete a user by id (admin action)."""
    with get_session() as session:
        user = session.query(User).filter(User.id == user_id).first()
        if not user:
            return False
        session.delete(user)
        return True


# ---------------------------------------------------------------------------
# TRIP CRUD
# ---------------------------------------------------------------------------

def create_trip(**kwargs) -> Optional[int]:
    """Create a new trip record."""
    with get_session() as session:
        trip = Trip(**kwargs)
        session.add(trip)
        session.flush()
        return trip.id


def get_trip_by_id(trip_id: int) -> Optional[Trip]:
    with get_session() as session:
        trip = session.query(Trip).filter(Trip.id == trip_id).first()
        session.expunge_all()
        return trip


def get_trips_by_user(user_id: int) -> List[Trip]:
    with get_session() as session:
        trips = session.query(Trip).filter(Trip.user_id == user_id).order_by(Trip.start_date.desc()).all()
        session.expunge_all()
        return trips


def get_all_trips(exclude_user_id: Optional[int] = None) -> List[Trip]:
    with get_session() as session:
        query = session.query(Trip)
        if exclude_user_id is not None:
            query = query.filter(Trip.user_id != exclude_user_id)
        trips = query.order_by(Trip.start_date.asc()).all()
        session.expunge_all()
        return trips


def search_trips(
    destination: Optional[str] = None,
    min_budget: Optional[float] = None,
    max_budget: Optional[float] = None,
    travel_style: Optional[str] = None,
    start_after: Optional[date] = None,
) -> List[Trip]:
    """Search trips using optional filters."""
    with get_session() as session:
        query = session.query(Trip)
        if destination:
            query = query.filter(Trip.destination.ilike(f"%{destination}%"))
        if min_budget is not None:
            query = query.filter(Trip.budget >= min_budget)
        if max_budget is not None:
            query = query.filter(Trip.budget <= max_budget)
        if travel_style:
            query = query.filter(Trip.travel_style == travel_style)
        if start_after is not None:
            query = query.filter(Trip.start_date >= start_after)
        trips = query.all()
        session.expunge_all()
        return trips


def delete_trip(trip_id: int) -> bool:
    with get_session() as session:
        trip = session.query(Trip).filter(Trip.id == trip_id).first()
        if not trip:
            return False
        session.delete(trip)
        return True


# ---------------------------------------------------------------------------
# BUDDY REQUEST CRUD
# ---------------------------------------------------------------------------

def create_buddy_request(sender: int, receiver: int, trip_id: Optional[int] = None) -> Optional[int]:
    """Create a buddy request, avoiding duplicate pending requests."""
    with get_session() as session:
        existing = (
            session.query(BuddyRequest)
            .filter(
                BuddyRequest.sender == sender,
                BuddyRequest.receiver == receiver,
                BuddyRequest.trip_id == trip_id,
                BuddyRequest.status == "pending",
            )
            .first()
        )
        if existing:
            return existing.id
        request = BuddyRequest(sender=sender, receiver=receiver, trip_id=trip_id, status="pending")
        session.add(request)
        session.flush()
        return request.id


def get_requests_for_user(user_id: int, status: Optional[str] = None) -> List[BuddyRequest]:
    """Get incoming buddy requests for a user, optionally filtered by status."""
    with get_session() as session:
        query = session.query(BuddyRequest).filter(BuddyRequest.receiver == user_id)
        if status:
            query = query.filter(BuddyRequest.status == status)
        results = query.order_by(BuddyRequest.created_at.desc()).all()
        session.expunge_all()
        return results


def get_sent_requests(user_id: int) -> List[BuddyRequest]:
    with get_session() as session:
        results = (
            session.query(BuddyRequest)
            .filter(BuddyRequest.sender == user_id)
            .order_by(BuddyRequest.created_at.desc())
            .all()
        )
        session.expunge_all()
        return results


def update_request_status(request_id: int, status: str) -> bool:
    """Update the status of a buddy request (accepted / rejected / cancelled)."""
    with get_session() as session:
        request = session.query(BuddyRequest).filter(BuddyRequest.id == request_id).first()
        if not request:
            return False
        request.status = status
        return True


# ---------------------------------------------------------------------------
# MESSAGE CRUD
# ---------------------------------------------------------------------------

def send_message(sender: int, receiver: int, message: str) -> Optional[int]:
    with get_session() as session:
        msg = Message(sender=sender, receiver=receiver, message=message, timestamp=datetime.utcnow())
        session.add(msg)
        session.flush()
        return msg.id


def get_conversation(user_id_a: int, user_id_b: int) -> List[Message]:
    """Return the full message thread between two users, ordered oldest first."""
    with get_session() as session:
        messages = (
            session.query(Message)
            .filter(
                or_(
                    and_(Message.sender == user_id_a, Message.receiver == user_id_b),
                    and_(Message.sender == user_id_b, Message.receiver == user_id_a),
                )
            )
            .order_by(Message.timestamp.asc())
            .all()
        )
        session.expunge_all()
        return messages


def get_conversation_partners(user_id: int) -> List[int]:
    """Return a list of distinct user ids this user has exchanged messages with."""
    with get_session() as session:
        sent_to = session.query(Message.receiver).filter(Message.sender == user_id).distinct()
        received_from = session.query(Message.sender).filter(Message.receiver == user_id).distinct()
        partner_ids = {row[0] for row in sent_to.all()} | {row[0] for row in received_from.all()}
        return list(partner_ids)


# ---------------------------------------------------------------------------
# REVIEW CRUD
# ---------------------------------------------------------------------------

def create_review(reviewer: int, reviewee: int, rating: int, review: str = "") -> Optional[int]:
    with get_session() as session:
        rev = Review(reviewer=reviewer, reviewee=reviewee, rating=rating, review=review)
        session.add(rev)
        session.flush()
        return rev.id


def get_reviews_for_user(user_id: int) -> List[Review]:
    with get_session() as session:
        reviews = session.query(Review).filter(Review.reviewee == user_id).order_by(Review.created_at.desc()).all()
        session.expunge_all()
        return reviews


def get_average_rating(user_id: int) -> float:
    reviews = get_reviews_for_user(user_id)
    if not reviews:
        return 0.0
    return round(sum(r.rating for r in reviews) / len(reviews), 1)


# ---------------------------------------------------------------------------
# WISHLIST CRUD
# ---------------------------------------------------------------------------

def add_to_wishlist(user_id: int, destination: str) -> Optional[int]:
    with get_session() as session:
        existing = (
            session.query(Wishlist)
            .filter(Wishlist.user_id == user_id, Wishlist.destination == destination)
            .first()
        )
        if existing:
            return existing.id
        item = Wishlist(user_id=user_id, destination=destination)
        session.add(item)
        session.flush()
        return item.id


def get_wishlist(user_id: int) -> List[Wishlist]:
    with get_session() as session:
        items = session.query(Wishlist).filter(Wishlist.user_id == user_id).all()
        session.expunge_all()
        return items


def remove_from_wishlist(item_id: int) -> bool:
    with get_session() as session:
        item = session.query(Wishlist).filter(Wishlist.id == item_id).first()
        if not item:
            return False
        session.delete(item)
        return True


# ---------------------------------------------------------------------------
# NOTIFICATION CRUD
# ---------------------------------------------------------------------------

def create_notification(user_id: int, title: str, description: str = "") -> Optional[int]:
    with get_session() as session:
        note = Notification(user_id=user_id, title=title, description=description, status="unread")
        session.add(note)
        session.flush()
        return note.id


def get_notifications(user_id: int, unread_only: bool = False) -> List[Notification]:
    with get_session() as session:
        query = session.query(Notification).filter(Notification.user_id == user_id)
        if unread_only:
            query = query.filter(Notification.status == "unread")
        notes = query.order_by(Notification.created_at.desc()).all()
        session.expunge_all()
        return notes


def mark_notification_read(notification_id: int) -> bool:
    with get_session() as session:
        note = session.query(Notification).filter(Notification.id == notification_id).first()
        if not note:
            return False
        note.status = "read"
        return True
