"""
models.py
---------
SQLAlchemy ORM models for the Travel Buddy Finder application.
"""

from datetime import datetime
from sqlalchemy import (
    Column,
    Integer,
    String,
    Float,
    Boolean,
    Date,
    DateTime,
    ForeignKey,
    Text,
)
from sqlalchemy.orm import declarative_base, relationship

Base = declarative_base()


class User(Base):
    """Represents a registered user of the platform."""

    __tablename__ = "users"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), nullable=False)
    email = Column(String(150), unique=True, nullable=False, index=True)
    password = Column(String(255), nullable=False)  # bcrypt hash
    phone = Column(String(20), nullable=True)
    gender = Column(String(20), nullable=True)
    age = Column(Integer, nullable=True)
    bio = Column(Text, nullable=True)
    city = Column(String(100), nullable=True)
    country = Column(String(100), nullable=True)
    profile_photo = Column(String(255), nullable=True)
    languages = Column(String(255), nullable=True)  # comma-separated
    interests = Column(String(255), nullable=True)  # comma-separated
    travel_style = Column(String(100), nullable=True)
    budget_preference = Column(String(50), nullable=True)
    verified = Column(Boolean, default=False)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    trips = relationship("Trip", back_populates="owner", cascade="all, delete-orphan")
    wishlist_items = relationship("Wishlist", back_populates="user", cascade="all, delete-orphan")
    notifications = relationship("Notification", back_populates="user", cascade="all, delete-orphan")


class Trip(Base):
    """Represents a travel plan created by a user."""

    __tablename__ = "trips"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    source = Column(String(100), nullable=False)
    destination = Column(String(100), nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    budget = Column(Float, nullable=False)
    transportation = Column(String(50), nullable=True)
    travel_style = Column(String(50), nullable=True)
    purpose = Column(String(100), nullable=True)
    description = Column(Text, nullable=True)
    max_companions = Column(Integer, default=1)
    created_at = Column(DateTime, default=datetime.utcnow)

    owner = relationship("User", back_populates="trips")


class BuddyRequest(Base):
    """Represents a buddy request sent from one user to another."""

    __tablename__ = "buddy_requests"

    id = Column(Integer, primary_key=True, autoincrement=True)
    sender = Column(Integer, ForeignKey("users.id"), nullable=False)
    receiver = Column(Integer, ForeignKey("users.id"), nullable=False)
    trip_id = Column(Integer, ForeignKey("trips.id"), nullable=True)
    status = Column(String(20), default="pending")  # pending / accepted / rejected / cancelled
    created_at = Column(DateTime, default=datetime.utcnow)


class Message(Base):
    """Represents a chat message between two users."""

    __tablename__ = "messages"

    id = Column(Integer, primary_key=True, autoincrement=True)
    sender = Column(Integer, ForeignKey("users.id"), nullable=False)
    receiver = Column(Integer, ForeignKey("users.id"), nullable=False)
    message = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)


class Review(Base):
    """Represents a review left by one user for another."""

    __tablename__ = "reviews"

    id = Column(Integer, primary_key=True, autoincrement=True)
    reviewer = Column(Integer, ForeignKey("users.id"), nullable=False)
    reviewee = Column(Integer, ForeignKey("users.id"), nullable=False)
    rating = Column(Integer, nullable=False)  # 1-5
    review = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Wishlist(Base):
    """Represents a saved destination a user wants to visit."""

    __tablename__ = "wishlist"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    destination = Column(String(100), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="wishlist_items")


class Notification(Base):
    """Represents a notification shown to a user."""

    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String(150), nullable=False)
    description = Column(Text, nullable=True)
    status = Column(String(20), default="unread")  # unread / read
    created_at = Column(DateTime, default=datetime.utcnow)

    user = relationship("User", back_populates="notifications")
