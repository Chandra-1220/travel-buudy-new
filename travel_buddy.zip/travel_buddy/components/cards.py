"""
cards.py
--------
Reusable "card" style UI components used throughout the app: buddy match
cards, trip cards, notification cards, and stat cards.
"""

from typing import List, Optional

import streamlit as st


def stat_card(label: str, value: str, icon: str = "📊") -> None:
    """Render a small statistic card, typically used on Dashboard/Analytics."""
    st.markdown(
        f"""
        <div class="tb-card" style="text-align:center;">
            <div style="font-size:1.6rem;">{icon}</div>
            <div class="tb-title" style="font-size:1.4rem;">{value}</div>
            <div class="tb-subtitle">{label}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def trip_card(destination: str, source: str, start_date, end_date, budget: float, travel_style: str = "") -> None:
    """Render a card summarizing a single trip."""
    style_badge = f"<span class='tb-badge'>{travel_style}</span>" if travel_style else ""
    st.markdown(
        f"""
        <div class="tb-card">
            <div class="tb-title">📍 {source} → {destination}</div>
            <div class="tb-subtitle">🗓️ {start_date} to {end_date} &nbsp;|&nbsp; 💰 ${budget:,.0f}</div>
            <div style="margin-top:0.4rem;">{style_badge}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def match_card(
    name: str,
    destination: str,
    budget: float,
    compatibility_score: float,
    common_interests: Optional[List[str]] = None,
    photo_url: Optional[str] = None,
) -> None:
    """Render a buddy-match card with a compatibility score."""
    interests_text = ", ".join(common_interests) if common_interests else "No shared interests yet"
    avatar = photo_url or "https://api.dicebear.com/7.x/initials/svg?seed=" + name.replace(" ", "")

    col1, col2 = st.columns([1, 4])
    with col1:
        st.image(avatar, width=64)
    with col2:
        st.markdown(
            f"""
            <div class="tb-title">{name}</div>
            <div class="tb-subtitle">📍 {destination} &nbsp;|&nbsp; 💰 ${budget:,.0f}</div>
            <div class="tb-subtitle">🤝 {interests_text}</div>
            <div class="tb-score-ring">{compatibility_score}% Match</div>
            """,
            unsafe_allow_html=True,
        )


def notification_card(title: str, description: str, timestamp: str, unread: bool = True) -> None:
    """Render a notification list item."""
    dot = "🔵" if unread else "⚪"
    st.markdown(
        f"""
        <div class="tb-card">
            <div class="tb-title">{dot} {title}</div>
            <div class="tb-subtitle">{description}</div>
            <div class="tb-subtitle" style="opacity:0.7;">{timestamp}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
