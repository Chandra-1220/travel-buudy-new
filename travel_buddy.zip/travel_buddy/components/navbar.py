"""
navbar.py
---------
Top navigation banner shown at the top of every page.
"""

import streamlit as st


def render_navbar(title: str, subtitle: str = "") -> None:
    """
    Render a premium gradient navbar banner with a title and optional subtitle.

    Args:
        title: Main page title (e.g. "Dashboard").
        subtitle: Optional smaller descriptive text.
    """
    subtitle_html = f"<p style='margin:0;opacity:0.9;'>{subtitle}</p>" if subtitle else ""
    st.markdown(
        f"""
        <div class="tb-navbar">
            <div>
                <h2>✈️ {title}</h2>
                {subtitle_html}
            </div>
            <div style="font-size:1.8rem;">🌍</div>
        </div>
        """,
        unsafe_allow_html=True,
    )
