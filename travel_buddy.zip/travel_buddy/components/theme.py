"""
theme.py
--------
Centralized custom CSS injected across every page to give the app a
consistent, premium, travel-themed look and feel. Supports a light and
dark mode toggle stored in session_state.
"""

import streamlit as st

LIGHT_PALETTE = {
    "primary": "#2E86AB",       # ocean blue
    "secondary": "#F6A94A",     # sunset orange
    "accent": "#3FBF7F",        # jungle green
    "background": "#F7F9FB",
    "surface": "#FFFFFF",
    "text": "#1F2933",
    "muted": "#6B7280",
}

DARK_PALETTE = {
    "primary": "#5FB4DE",
    "secondary": "#F6A94A",
    "accent": "#4CD98A",
    "background": "#12181F",
    "surface": "#1B242D",
    "text": "#EDF2F7",
    "muted": "#9AA5B1",
}


def get_palette() -> dict:
    """Return the active color palette based on the current theme mode."""
    mode = st.session_state.get("theme_mode", "light")
    return DARK_PALETTE if mode == "dark" else LIGHT_PALETTE


def inject_custom_css() -> None:
    """Inject the global custom CSS for cards, buttons, sidebar, etc."""
    palette = get_palette()

    css = f"""
    <style>
        .stApp {{
            background-color: {palette['background']};
            color: {palette['text']};
        }}

        section[data-testid="stSidebar"] {{
            background-color: {palette['surface']};
            border-right: 1px solid rgba(0,0,0,0.06);
        }}

        div.stButton > button {{
            border-radius: 999px;
            border: none;
            background: linear-gradient(135deg, {palette['primary']}, {palette['accent']});
            color: white;
            font-weight: 600;
            padding: 0.5rem 1.4rem;
            transition: transform 0.15s ease, box-shadow 0.15s ease;
        }}

        div.stButton > button:hover {{
            transform: translateY(-2px);
            box-shadow: 0 6px 14px rgba(0,0,0,0.15);
        }}

        .tb-card {{
            background-color: {palette['surface']};
            border-radius: 16px;
            padding: 1.2rem 1.4rem;
            box-shadow: 0 4px 18px rgba(0,0,0,0.06);
            margin-bottom: 1rem;
            border: 1px solid rgba(0,0,0,0.04);
        }}

        .tb-card:hover {{
            box-shadow: 0 8px 24px rgba(0,0,0,0.12);
        }}

        .tb-badge {{
            display: inline-block;
            padding: 0.15rem 0.7rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 700;
            color: white;
            background: {palette['accent']};
        }}

        .tb-title {{
            font-size: 1.05rem;
            font-weight: 700;
            color: {palette['text']};
            margin-bottom: 0.2rem;
        }}

        .tb-subtitle {{
            font-size: 0.85rem;
            color: {palette['muted']};
        }}

        .tb-navbar {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.8rem 1.2rem;
            background: linear-gradient(135deg, {palette['primary']}, {palette['accent']});
            border-radius: 14px;
            color: white;
            margin-bottom: 1.2rem;
        }}

        .tb-navbar h2 {{
            color: white;
            margin: 0;
        }}

        .tb-footer {{
            text-align: center;
            color: {palette['muted']};
            padding: 1.5rem 0 0.5rem 0;
            font-size: 0.8rem;
        }}

        .tb-score-ring {{
            font-weight: 800;
            font-size: 1.4rem;
            color: {palette['primary']};
        }}
    </style>
    """
    st.markdown(css, unsafe_allow_html=True)


def theme_toggle() -> None:
    """Render a light/dark mode toggle in the sidebar."""
    current = st.session_state.get("theme_mode", "light")
    label = "🌙 Dark Mode" if current == "light" else "☀️ Light Mode"
    if st.sidebar.button(label, use_container_width=True):
        st.session_state["theme_mode"] = "dark" if current == "light" else "light"
        st.rerun()
