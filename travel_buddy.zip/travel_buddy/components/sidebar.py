"""
sidebar.py
----------
Professional sidebar navigation with user info, quick links, and
theme toggle. Streamlit's multi-page app automatically lists pages,
so this component supplements it with account context.
"""

import streamlit as st

from auth.auth import is_authenticated, is_admin, logout_user
from components.theme import theme_toggle
from database import crud


def render_sidebar() -> None:
    """Render the sidebar header shown above the auto-generated page list."""
    with st.sidebar:
        st.markdown("## 🧳 Travel Buddy Finder")
        st.caption("Find your perfect travel companion")
        st.divider()

        if is_authenticated():
            user_id = st.session_state.get("user_id")
            user = crud.get_user_by_id(user_id) if user_id else None
            name = user.name if user else st.session_state.get("user_name", "Traveler")

            st.markdown(f"**👋 Hi, {name}**")
            if is_admin():
                st.markdown("<span class='tb-badge'>ADMIN</span>", unsafe_allow_html=True)

            unread = len(crud.get_notifications(user_id, unread_only=True)) if user_id else 0
            if unread:
                st.info(f"🔔 {unread} new notification(s)")

            if st.button("🚪 Logout", use_container_width=True):
                logout_user()
                st.rerun()
        else:
            st.info("Please log in or register to get started.")

        st.divider()
        theme_toggle()
        st.divider()
        st.caption("© 2026 Travel Buddy Finder")
