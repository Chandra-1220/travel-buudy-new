"""
footer.py
---------
Simple footer rendered at the bottom of every page.
"""

import streamlit as st


def render_footer() -> None:
    """Render the global footer."""
    st.markdown(
        """
        <div class="tb-footer">
            🧳 Travel Buddy Finder &nbsp;•&nbsp; Built with Streamlit &nbsp;•&nbsp;
            Travel safe, travel together 🌍
        </div>
        """,
        unsafe_allow_html=True,
    )
