"""
app.py
------
Main entry point for the Travel Buddy Finder Streamlit application.

Responsibilities:
    - Initialize the database (creating tables on first run).
    - Configure global Streamlit page settings.
    - Inject custom CSS theming.
    - Render the sidebar and route to Home if not authenticated,
      or Dashboard if the user is logged in.

Individual feature pages live under `pages/` and are auto-discovered by
Streamlit's built-in multipage app support.
"""

import logging

import streamlit as st

from database.database import init_db
from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from auth.auth import is_authenticated

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
)
logger = logging.getLogger(__name__)


def configure_page() -> None:
    """Set Streamlit page-wide configuration."""
    st.set_page_config(
        page_title="Travel Buddy Finder",
        page_icon="🧳",
        layout="wide",
        initial_sidebar_state="expanded",
    )


def bootstrap_database() -> None:
    """Initialize the database once per session."""
    if "db_initialized" not in st.session_state:
        try:
            init_db()
            st.session_state["db_initialized"] = True
        except Exception as exc:
            logger.exception("Database initialization failed: %s", exc)
            st.error("Failed to initialize the database. Please check the logs.")


def render_landing() -> None:
    """Render the public landing/welcome view for logged-out visitors."""
    render_navbar("Welcome to Travel Buddy Finder", "Find your perfect travel companion")

    col1, col2 = st.columns([3, 2])
    with col1:
        st.markdown(
            """
            ### Travel farther, together.
            Travel Buddy Finder connects solo travelers with compatible
            companions based on destination, dates, budget, interests, and
            travel style. Create a trip, discover matches with an
            AI-powered compatibility score, and chat before you even pack
            your bags.
            """
        )
        st.markdown("Use the sidebar to **Login** or **Register** to get started.")
        st.info("Demo admin login: `admin@travelbuddy.com` / `Admin@123`  \nDemo user password: `Password123`")
    with col2:
        st.markdown(
            """
            <div class="tb-card">
                <div class="tb-title">✨ Why Travel Buddy Finder?</div>
                <ul>
                    <li>🎯 Smart compatibility scoring</li>
                    <li>🗺️ Interactive destination maps</li>
                    <li>💬 Built-in buddy chat</li>
                    <li>⭐ Trusted review system</li>
                    <li>📊 Personal travel analytics</li>
                </ul>
            </div>
            """,
            unsafe_allow_html=True,
        )


def main() -> None:
    """Application entry point."""
    configure_page()
    bootstrap_database()
    inject_custom_css()
    render_sidebar()

    if is_authenticated():
        st.switch_page("pages/Dashboard.py")
    else:
        render_landing()

    render_footer()


if __name__ == "__main__":
    main()
