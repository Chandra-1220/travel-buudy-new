"""
auth.py
-------
Authentication and session-management helpers built on top of
Streamlit's `session_state`. Handles login, logout, registration
validation glue, and route protection for pages.
"""

import logging
from typing import Optional

import streamlit as st

from auth.hash import hash_password, verify_password
from database import crud
from database.models import User

logger = logging.getLogger(__name__)


def login_user(email: str, password: str) -> bool:
    """
    Attempt to authenticate a user and, on success, populate session_state.

    Args:
        email: User-provided email.
        password: User-provided plaintext password.

    Returns:
        True if login succeeded, False otherwise.
    """
    user = crud.get_user_by_email(email.lower().strip())
    if user is None:
        return False
    if not verify_password(password, user.password):
        return False

    st.session_state["authenticated"] = True
    st.session_state["user_id"] = user.id
    st.session_state["user_name"] = user.name
    st.session_state["user_email"] = user.email
    st.session_state["is_admin"] = bool(user.is_admin)
    logger.info("User %s logged in", user.email)
    return True


def logout_user() -> None:
    """Clear all authentication-related keys from session_state."""
    for key in ("authenticated", "user_id", "user_name", "user_email", "is_admin"):
        st.session_state.pop(key, None)


def register_user(
    name: str,
    email: str,
    password: str,
    phone: str,
    gender: str,
    age: int,
    city: str,
    country: str,
    profile_photo: Optional[str] = None,
) -> Optional[str]:
    """
    Register a new user after hashing their password.

    Returns:
        None on success, or an error message string on failure.
    """
    existing = crud.get_user_by_email(email.lower().strip())
    if existing is not None:
        return "An account with this email already exists."

    hashed = hash_password(password)
    try:
        crud.create_user(
            name=name.strip(),
            email=email.lower().strip(),
            password=hashed,
            phone=phone,
            gender=gender,
            age=age,
            city=city,
            country=country,
            profile_photo=profile_photo,
            verified=False,
            is_admin=False,
        )
    except Exception as exc:
        logger.exception("Failed to register user: %s", exc)
        return "Something went wrong while creating your account. Please try again."
    return None


def is_authenticated() -> bool:
    """Return True if a user is currently logged in."""
    return bool(st.session_state.get("authenticated", False))


def is_admin() -> bool:
    """Return True if the currently logged-in user has admin privileges."""
    return bool(st.session_state.get("is_admin", False))


def get_current_user_id() -> Optional[int]:
    """Return the id of the currently logged-in user, or None."""
    return st.session_state.get("user_id")


def require_login() -> None:
    """
    Guard function to place at the top of any protected page.
    Stops page execution and shows a warning if the user is not logged in.
    """
    if not is_authenticated():
        st.warning("Please log in to access this page.")
        st.stop()


def require_admin() -> None:
    """Guard function for admin-only pages."""
    require_login()
    if not is_admin():
        st.error("You do not have permission to view this page.")
        st.stop()
