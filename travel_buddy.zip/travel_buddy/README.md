# 🧳 Travel Buddy Finder

An AI-powered travel companion platform built with **Streamlit**, **SQLAlchemy**, and **scikit-learn**. Users create trips, get ranked buddy matches from a weighted compatibility algorithm, send buddy requests, chat, review each other, and track their travel analytics.

---

## ✨ Features

- Secure registration & login (bcrypt-hashed passwords, session-based auth)
- Editable profile with photo upload, languages, interests, and travel style
- Trip creation with an interactive Folium route map
- **AI-powered buddy matching** — weighted score across destination, date overlap, budget, interests, and travel style
- Trip search with filters (destination, budget, style)
- Buddy request workflow (send / accept / reject / cancel)
- In-app chat between matched buddies
- Star reviews with average rating
- Destination wishlist with map view
- Personal & platform-wide analytics (Plotly charts)
- Notification center
- Role-based Admin dashboard (manage users & trips)
- Light / Dark theme toggle
- Pre-loaded with realistic sample data (30 users, 80 trips, 200 buddy requests)

---

## 🛠️ Tech Stack

| Layer          | Technology                         |
|----------------|-------------------------------------|
| Frontend       | Streamlit                          |
| Backend        | Python                             |
| Database       | SQLite + SQLAlchemy ORM            |
| Auth           | Session state + bcrypt             |
| Maps           | Folium + streamlit-folium          |
| Charts         | Plotly                             |
| Data handling  | Pandas                             |
| ML matching    | scikit-learn (cosine similarity)   |

---

## 📁 Folder Structure

```
travel_buddy/
│
├── app.py                  # Main entry point
├── requirements.txt
├── README.md
├── database.db              # Created automatically on first run
│
├── assets/
│   └── profile_photos/      # Uploaded profile pictures
│
├── pages/                   # One file per Streamlit page
│   ├── Home.py
│   ├── Login.py
│   ├── Register.py
│   ├── Dashboard.py
│   ├── Profile.py
│   ├── Create_Trip.py
│   ├── Find_Buddy.py
│   ├── My_Trips.py
│   ├── Chat.py
│   ├── Notifications.py
│   ├── Reviews.py
│   ├── Wishlist.py
│   ├── Analytics.py
│   ├── Settings.py
│   └── Admin.py
│
├── database/
│   ├── models.py             # SQLAlchemy ORM models
│   ├── database.py           # Engine / session management
│   └── crud.py                # All create/read/update/delete logic
│
├── auth/
│   ├── auth.py                # Login/register/session helpers
│   └── hash.py                 # bcrypt password hashing
│
├── utils/
│   ├── matching.py             # Weighted compatibility scoring algorithm
│   ├── recommendation.py       # scikit-learn cosine-similarity suggestions
│   ├── map_utils.py            # Folium map builders + city gazetteer
│   ├── notifications.py        # Notification copy helpers
│   └── validators.py           # Input validation
│
├── components/
│   ├── theme.py                 # Custom CSS + light/dark palettes
│   ├── navbar.py
│   ├── sidebar.py
│   ├── cards.py
│   └── footer.py
│
└── data/
    └── seed_data.py            # Sample data generator
```

---

## 🚀 Installation & Running Locally

1. **Clone / unzip the project** and move into the folder:
   ```bash
   cd travel_buddy
   ```

2. **Create a virtual environment** (recommended):
   ```bash
   python -m venv venv
   source venv/bin/activate      # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Seed the database** with sample data (30 users, 80 trips, 200 buddy requests):
   ```bash
   python -m data.seed_data
   ```
   This creates `database.db` in the project root. If you skip this step, the
   database will still be created automatically on first launch, just empty.

5. **Run the app**:
   ```bash
   streamlit run app.py
   ```

6. Open the URL Streamlit prints (usually `http://localhost:8501`).

### Demo Credentials

| Role  | Email                      | Password      |
|-------|-----------------------------|---------------|
| Admin | admin@travelbuddy.com       | Admin@123     |
| User  | any seeded user's email     | Password123   |

You can find seeded user emails via the Admin dashboard after logging in as admin.

---

## 🧠 Matching Algorithm

Each candidate trip is scored against the user's selected trip using fixed weights:

| Factor            | Weight |
|--------------------|--------|
| Destination match  | 40%    |
| Date overlap        | 20%    |
| Budget similarity   | 15%    |
| Shared interests     | 15%    |
| Travel style match  | 10%    |

The result is a single 0–100% compatibility score, and matches are sorted highest to lowest. See `utils/matching.py` for the full implementation.

The Dashboard also surfaces general "suggested buddies" (even without a trip) using a scikit-learn cosine-similarity model over age and shared interests — see `utils/recommendation.py`.

---

## 🔒 Security Notes

- Passwords are hashed with **bcrypt** before storage — plaintext passwords are never persisted.
- All database access goes through SQLAlchemy's ORM with parameterized queries, avoiding raw SQL string interpolation.
- Every protected page calls `require_login()` (or `require_admin()`), guarding access based on `st.session_state`.
- Basic input validation is centralized in `utils/validators.py`.

> **Note:** This is a demo/portfolio-grade application. For a real production deployment you would add CSRF protection, rate limiting, email verification, HTTPS enforcement, and a managed database (e.g. Postgres) instead of SQLite.

---

## 🖼️ Screenshots

*(Add screenshots here after running the app locally)*

- `screenshots/dashboard.png`
- `screenshots/find_buddy.png`
- `screenshots/chat.png`
- `screenshots/analytics.png`

---

## 🔮 Future Improvements

- Real-time chat via WebSockets instead of polling on rerun
- Email/SMS notifications and password reset delivery
- Geocoding via a live API (Google/Mapbox) instead of the static city gazetteer
- Payment integration for trip cost-splitting
- Mobile-responsive PWA wrapper
- Multi-language i18n support
- Deploy to Streamlit Community Cloud / Docker + a managed Postgres instance

---

## 📄 License

This project was generated as a demo/portfolio application. Use and modify freely.
