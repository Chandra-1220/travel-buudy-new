"""
notifications.py
-----------------
Convenience wrappers for generating common in-app notifications.
Keeps notification copywriting consistent across the application.
"""

from database import crud


def notify_buddy_request(receiver_id: int, sender_name: str) -> None:
    """Notify a user that they received a new buddy request."""
    crud.create_notification(
        user_id=receiver_id,
        title="New Buddy Request",
        description=f"{sender_name} sent you a travel buddy request.",
    )


def notify_request_accepted(sender_id: int, receiver_name: str) -> None:
    """Notify the original sender that their buddy request was accepted."""
    crud.create_notification(
        user_id=sender_id,
        title="Buddy Request Accepted",
        description=f"{receiver_name} accepted your travel buddy request!",
    )


def notify_request_rejected(sender_id: int, receiver_name: str) -> None:
    """Notify the original sender that their buddy request was rejected."""
    crud.create_notification(
        user_id=sender_id,
        title="Buddy Request Declined",
        description=f"{receiver_name} declined your travel buddy request.",
    )


def notify_new_message(receiver_id: int, sender_name: str) -> None:
    """Notify a user that they received a new chat message."""
    crud.create_notification(
        user_id=receiver_id,
        title="New Message",
        description=f"You have a new message from {sender_name}.",
    )


def notify_new_review(reviewee_id: int, reviewer_name: str, rating: int) -> None:
    """Notify a user that they received a new review."""
    crud.create_notification(
        user_id=reviewee_id,
        title="New Review Received",
        description=f"{reviewer_name} left you a {rating}-star review.",
    )


def notify_trip_reminder(user_id: int, destination: str, days_away: int) -> None:
    """Notify a user that an upcoming trip is approaching."""
    crud.create_notification(
        user_id=user_id,
        title="Upcoming Trip Reminder",
        description=f"Your trip to {destination} starts in {days_away} day(s). Get ready!",
    )
