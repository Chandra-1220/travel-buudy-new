"""
map_utils.py
------------
Helpers for building Folium maps used in the Create Trip and Find Buddy
pages. Uses a small static lookup table of city coordinates so the app
works fully offline without calling an external geocoding API.
"""

import logging
from typing import Optional, Tuple, List

import folium

logger = logging.getLogger(__name__)

# A small static gazetteer of popular travel destinations. Extend as needed.
CITY_COORDINATES = {
    "paris": (48.8566, 2.3522),
    "london": (51.5074, -0.1278),
    "new york": (40.7128, -74.0060),
    "tokyo": (35.6762, 139.6503),
    "rome": (41.9028, 12.4964),
    "bali": (-8.3405, 115.0920),
    "dubai": (25.2048, 55.2708),
    "sydney": (-33.8688, 151.2093),
    "bangkok": (13.7563, 100.5018),
    "barcelona": (41.3851, 2.1734),
    "singapore": (1.3521, 103.8198),
    "amsterdam": (52.3676, 4.9041),
    "goa": (15.2993, 74.1240),
    "mumbai": (19.0760, 72.8777),
    "delhi": (28.7041, 77.1025),
    "hyderabad": (17.3850, 78.4867),
    "bangalore": (12.9716, 77.5946),
    "cape town": (-33.9249, 18.4241),
    "istanbul": (41.0082, 28.9784),
    "rio de janeiro": (-22.9068, -43.1729),
    "los angeles": (34.0522, -118.2437),
    "san francisco": (37.7749, -122.4194),
    "berlin": (52.5200, 13.4050),
    "seoul": (37.5665, 126.9780),
    "kathmandu": (27.7172, 85.3240),
}


def get_coordinates(city_name: str) -> Optional[Tuple[float, float]]:
    """Look up latitude/longitude for a known city name, case-insensitive."""
    if not city_name:
        return None
    return CITY_COORDINATES.get(city_name.strip().lower())


def build_route_map(source: str, destination: str) -> folium.Map:
    """
    Build a Folium map showing a source and destination marker, connected
    by a straight line, for use on the Create Trip page.
    """
    source_coords = get_coordinates(source) or (20.5937, 78.9629)  # default: India centroid
    dest_coords = get_coordinates(destination) or (20.5937, 78.9629)

    midpoint = (
        (source_coords[0] + dest_coords[0]) / 2,
        (source_coords[1] + dest_coords[1]) / 2,
    )

    fmap = folium.Map(location=midpoint, zoom_start=3, tiles="CartoDB positron")

    folium.Marker(
        location=source_coords,
        popup=f"Source: {source}",
        icon=folium.Icon(color="blue", icon="play"),
    ).add_to(fmap)

    folium.Marker(
        location=dest_coords,
        popup=f"Destination: {destination}",
        icon=folium.Icon(color="red", icon="flag"),
    ).add_to(fmap)

    folium.PolyLine(
        locations=[source_coords, dest_coords],
        color="#2E86AB",
        weight=3,
        dash_array="8",
    ).add_to(fmap)

    return fmap


def build_destinations_map(destinations: List[str]) -> folium.Map:
    """Build a Folium map with a marker for every destination in a list."""
    fmap = folium.Map(location=(20.5937, 78.9629), zoom_start=2, tiles="CartoDB positron")

    for dest in destinations:
        coords = get_coordinates(dest)
        if coords:
            folium.Marker(
                location=coords,
                popup=dest,
                icon=folium.Icon(color="green", icon="map-marker"),
            ).add_to(fmap)

    return fmap
