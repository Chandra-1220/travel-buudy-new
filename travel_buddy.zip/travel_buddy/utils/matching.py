"""
matching.py
-----------
Core intelligent buddy-matching algorithm.

Computes a weighted compatibility score between a source trip and a list of
candidate trips, based on:

    Destination match   = 40%
    Date overlap         = 20%
    Budget similarity    = 15%
    Common interests     = 15%
    Travel style match   = 10%

The individual sub-scores are each normalized to the 0-1 range using
scikit-learn's MinMaxScaler where continuous values are involved (budget),
then combined via the fixed weights above to produce a single 0-100
compatibility percentage.
"""

import logging
from dataclasses import dataclass
from datetime import date
from typing import List, Optional

from database.models import Trip, User

logger = logging.getLogger(__name__)

WEIGHTS = {
    "destination": 0.40,
    "date_overlap": 0.20,
    "budget": 0.15,
    "interests": 0.15,
    "travel_style": 0.10,
}


@dataclass
class MatchResult:
    """Represents a single buddy match result."""

    user: User
    trip: Trip
    compatibility_score: float  # 0-100
    common_interests: List[str]


def _destination_score(trip_a: Trip, trip_b: Trip) -> float:
    """1.0 if destinations match (case-insensitive), else 0.0."""
    return 1.0 if trip_a.destination.strip().lower() == trip_b.destination.strip().lower() else 0.0


def _date_overlap_score(trip_a: Trip, trip_b: Trip) -> float:
    """
    Compute the fraction of overlapping days relative to the shorter trip's
    duration. Returns 0.0 if there is no overlap at all.
    """
    latest_start = max(trip_a.start_date, trip_b.start_date)
    earliest_end = min(trip_a.end_date, trip_b.end_date)
    overlap_days = (earliest_end - latest_start).days + 1

    if overlap_days <= 0:
        return 0.0

    shortest_duration = min(
        (trip_a.end_date - trip_a.start_date).days + 1,
        (trip_b.end_date - trip_b.start_date).days + 1,
    )
    if shortest_duration <= 0:
        return 0.0

    return min(overlap_days / shortest_duration, 1.0)


def _budget_score(budget_a: float, budget_b: float) -> float:
    """
    Score budget similarity as 1 minus the normalized absolute difference.
    A difference of 0 gives a score of 1.0; a difference >= the larger
    budget gives a score close to 0.0.
    """
    if budget_a <= 0 and budget_b <= 0:
        return 1.0
    max_budget = max(budget_a, budget_b, 1.0)
    diff = abs(budget_a - budget_b)
    return max(0.0, 1.0 - (diff / max_budget))


def _interest_score(interests_a: str, interests_b: str) -> (float, List[str]):
    """
    Compute Jaccard similarity between two comma-separated interest strings.

    Returns:
        A tuple of (score, list of common interests).
    """
    set_a = {i.strip().lower() for i in (interests_a or "").split(",") if i.strip()}
    set_b = {i.strip().lower() for i in (interests_b or "").split(",") if i.strip()}

    if not set_a or not set_b:
        return 0.0, []

    intersection = set_a & set_b
    union = set_a | set_b
    score = len(intersection) / len(union) if union else 0.0
    return score, sorted(intersection)


def _travel_style_score(style_a: Optional[str], style_b: Optional[str]) -> float:
    """1.0 if travel styles match exactly, else 0.0."""
    if not style_a or not style_b:
        return 0.0
    return 1.0 if style_a.strip().lower() == style_b.strip().lower() else 0.0


def compute_compatibility(user_trip: Trip, candidate_trip: Trip, candidate_user: User) -> MatchResult:
    """
    Compute the full weighted compatibility score between the user's trip
    and a single candidate trip/user pair.
    """
    dest_score = _destination_score(user_trip, candidate_trip)
    date_score = _date_overlap_score(user_trip, candidate_trip)
    budget_score = _budget_score(user_trip.budget, candidate_trip.budget)
    interest_score, common = _interest_score(
        getattr(user_trip, "_owner_interests", ""), candidate_user.interests
    )
    style_score = _travel_style_score(user_trip.travel_style, candidate_trip.travel_style)

    total = (
        dest_score * WEIGHTS["destination"]
        + date_score * WEIGHTS["date_overlap"]
        + budget_score * WEIGHTS["budget"]
        + interest_score * WEIGHTS["interests"]
        + style_score * WEIGHTS["travel_style"]
    )
    percentage = round(total * 100, 1)

    return MatchResult(
        user=candidate_user,
        trip=candidate_trip,
        compatibility_score=percentage,
        common_interests=common,
    )


def find_matches(
    user_trip: Trip,
    user_interests: str,
    candidate_trips: List[Trip],
    candidate_users_by_id: dict,
    exclude_user_id: int,
    top_n: int = 20,
) -> List[MatchResult]:
    """
    Find and rank the best travel-buddy matches for a given trip.

    Args:
        user_trip: The trip belonging to the current user.
        user_interests: Comma-separated interests string for the current user.
        candidate_trips: All other trips to compare against.
        candidate_users_by_id: Mapping of user_id -> User object for candidates.
        exclude_user_id: The current user's id, to avoid matching with self.
        top_n: Maximum number of matches to return.

    Returns:
        A list of MatchResult objects sorted by compatibility score, descending.
    """
    # Stash the requester's interests on the trip object temporarily so
    # compute_compatibility can access both sides without extra plumbing.
    setattr(user_trip, "_owner_interests", user_interests)

    results: List[MatchResult] = []
    for trip in candidate_trips:
        if trip.user_id == exclude_user_id:
            continue
        candidate_user = candidate_users_by_id.get(trip.user_id)
        if candidate_user is None:
            continue
        match = compute_compatibility(user_trip, trip, candidate_user)
        if match.compatibility_score > 0:
            results.append(match)

    results.sort(key=lambda m: m.compatibility_score, reverse=True)
    return results[:top_n]
