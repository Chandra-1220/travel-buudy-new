"""
recommendation.py
------------------
Lightweight recommendation engine used on the Dashboard to suggest travel
buddies even when the user hasn't created a trip yet. Uses scikit-learn's
cosine-similarity based Nearest Neighbors on a simple numeric/interest
feature vector built from user profiles.
"""

import logging
from typing import List, Tuple

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

from database.models import User

logger = logging.getLogger(__name__)


def _vectorize_users(users: List[User], all_interests: List[str]) -> np.ndarray:
    """
    Build a simple feature matrix for a list of users.

    Features:
        - normalized age
        - one-hot encoded interests (multi-hot, since a user can have several)
    """
    ages = np.array([u.age or 30 for u in users], dtype=float).reshape(-1, 1)
    max_age = max(ages.max(), 1.0)
    normalized_ages = ages / max_age

    interest_matrix = np.zeros((len(users), len(all_interests)))
    for i, user in enumerate(users):
        user_interests = {x.strip().lower() for x in (user.interests or "").split(",") if x.strip()}
        for j, interest in enumerate(all_interests):
            if interest in user_interests:
                interest_matrix[i, j] = 1.0

    return np.hstack([normalized_ages, interest_matrix])


def recommend_similar_users(target_user: User, all_users: List[User], top_n: int = 5) -> List[Tuple[User, float]]:
    """
    Recommend users most similar to the target user based on age and shared
    interests, using cosine similarity over a feature vector.

    Args:
        target_user: The user to generate recommendations for.
        all_users: Pool of candidate users (should exclude target_user already,
                   but this function will also filter defensively).
        top_n: Number of recommendations to return.

    Returns:
        A list of (User, similarity_score) tuples sorted descending by score.
    """
    candidates = [u for u in all_users if u.id != target_user.id]
    if not candidates:
        return []

    # Build vocabulary of all interests seen across target + candidates
    interest_set = set()
    for user in [target_user] + candidates:
        interest_set.update(x.strip().lower() for x in (user.interests or "").split(",") if x.strip())
    all_interests = sorted(interest_set)

    if not all_interests:
        # No interest data at all -- fall back to age-only similarity
        pass

    combined = [target_user] + candidates
    matrix = _vectorize_users(combined, all_interests)

    try:
        similarities = cosine_similarity(matrix[0:1], matrix[1:])[0]
    except Exception as exc:
        logger.exception("Failed to compute similarity matrix: %s", exc)
        return []

    scored = list(zip(candidates, similarities))
    scored.sort(key=lambda pair: pair[1], reverse=True)

    return [(user, round(float(score) * 100, 1)) for user, score in scored[:top_n]]
