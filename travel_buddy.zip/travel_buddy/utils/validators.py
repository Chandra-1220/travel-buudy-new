"""
validators.py
-------------
Input validation helpers used across registration, profile, and trip forms.
"""

import re
from datetime import date
from typing import Optional

EMAIL_REGEX = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")
PHONE_REGEX = re.compile(r"^\+?[0-9]{7,15}$")


def is_valid_email(email: str) -> bool:
    """Return True if the string looks like a valid email address."""
    return bool(email) and bool(EMAIL_REGEX.match(email.strip()))


def is_valid_phone(phone: str) -> bool:
    """Return True if the string looks like a valid phone number."""
    if not phone:
        return True  # phone is optional
    return bool(PHONE_REGEX.match(phone.strip()))


def is_strong_password(password: str) -> Optional[str]:
    """
    Validate password strength.

    Returns:
        None if the password is strong enough, otherwise an error message.
    """
    if len(password) < 8:
        return "Password must be at least 8 characters long."
    if not re.search(r"[A-Z]", password):
        return "Password must contain at least one uppercase letter."
    if not re.search(r"[a-z]", password):
        return "Password must contain at least one lowercase letter."
    if not re.search(r"[0-9]", password):
        return "Password must contain at least one digit."
    return None


def passwords_match(password: str, confirm_password: str) -> bool:
    """Return True if the two password fields match."""
    return password == confirm_password


def is_valid_age(age: int, minimum: int = 16, maximum: int = 100) -> bool:
    """Return True if age falls within an acceptable range."""
    return minimum <= age <= maximum


def is_valid_name(name: str) -> bool:
    """Return True if the name is non-empty and contains only reasonable characters."""
    if not name or not name.strip():
        return False
    return bool(re.match(r"^[A-Za-z\s.'-]{2,100}$", name.strip()))


def validate_trip_dates(start_date: date, end_date: date) -> Optional[str]:
    """
    Validate that trip dates are logical.

    Returns:
        None if valid, otherwise an error message.
    """
    if start_date < date.today():
        return "Start date cannot be in the past."
    if end_date < start_date:
        return "End date must be on or after the start date."
    return None


def sanitize_text(text: str, max_length: int = 1000) -> str:
    """
    Basic sanitization for free-text fields: strips whitespace and enforces
    a maximum length. SQL injection is separately mitigated by using
    SQLAlchemy's parameterized queries everywhere (never raw string SQL).
    """
    if not text:
        return ""
    return text.strip()[:max_length]
