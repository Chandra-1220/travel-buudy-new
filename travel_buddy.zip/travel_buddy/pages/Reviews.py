"""
Reviews.py
----------
Lets a user rate and review past travel buddies, and view reviews they've
received from others.
"""

import streamlit as st

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from auth.auth import require_login, get_current_user_id
from database import crud
from utils.notifications import notify_new_review
from utils.validators import sanitize_text

st.set_page_config(page_title="Reviews | Travel Buddy Finder", page_icon="⭐", layout="wide")

inject_custom_css()
render_sidebar()
require_login()

user_id = get_current_user_id()
user = crud.get_user_by_id(user_id)

render_navbar("Reviews", "Rate your travel partners and build trust in the community")

tab_write, tab_received = st.tabs(["✍️ Write a Review", "⭐ Reviews Received"])

with tab_write:
    # Anyone the user has an accepted buddy connection with is eligible for review.
    accepted = [
        r for r in (crud.get_sent_requests(user_id) + crud.get_requests_for_user(user_id))
        if r.status == "accepted"
    ]
    reviewee_ids = {r.receiver if r.sender == user_id else r.sender for r in accepted}
    reviewee_ids.discard(user_id)

    if not reviewee_ids:
        st.info("You can review a travel buddy once you have an accepted buddy request with them.")
    else:
        candidates = {crud.get_user_by_id(uid).name: uid for uid in reviewee_ids if crud.get_user_by_id(uid)}
        selected_name = st.selectbox("Select a travel buddy to review", list(candidates.keys()))
        rating = st.slider("Rating", 1, 5, 5)
        review_text = st.text_area("Your review", placeholder="How was your trip together?")

        if st.button("Submit Review"):
            reviewee_id = candidates[selected_name]
            crud.create_review(reviewer=user_id, reviewee=reviewee_id, rating=rating, review=sanitize_text(review_text, 1000))
            notify_new_review(reviewee_id, user.name, rating)
            st.success("Thank you for your review!")

with tab_received:
    reviews = crud.get_reviews_for_user(user_id)
    avg = crud.get_average_rating(user_id)
    st.metric("Average Rating", f"{avg} ⭐" if avg else "No ratings yet")

    if not reviews:
        st.info("No reviews yet.")
    else:
        for rev in reviews:
            reviewer = crud.get_user_by_id(rev.reviewer)
            stars = "⭐" * rev.rating
            st.markdown(
                f"""
                <div class="tb-card">
                    <div class="tb-title">{stars} — {reviewer.name if reviewer else 'Anonymous'}</div>
                    <div class="tb-subtitle">{rev.review or 'No comment left.'}</div>
                    <div class="tb-subtitle" style="opacity:0.7;">{rev.created_at.strftime('%b %d, %Y')}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )

render_footer()
