"""
Home.py
-------
Public landing page, also reachable directly from the sidebar navigation.
Mirrors the welcome content shown at app.py root when logged out, and
redirects authenticated users straight to their Dashboard.
"""

import streamlit as st

from database.database import init_db
from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from auth.auth import is_authenticated

st.set_page_config(page_title="Home | Travel Buddy Finder", page_icon="🏠", layout="wide")

if "db_initialized" not in st.session_state:
    init_db()
    st.session_state["db_initialized"] = True

inject_custom_css()
render_sidebar()

if is_authenticated():
    st.switch_page("pages/Dashboard.py")

render_navbar("Welcome to Travel Buddy Finder", "Find your perfect travel companion")

col1, col2 = st.columns([3, 2])
with col1:
    st.markdown(
        """
        ### Your next adventure, better with company.
        Create a trip, tell us your travel style and interests, and let our
        AI-powered matching engine surface the most compatible travel buddies
        for your destination and dates.
        """
    )
    st.page_link("pages/Register.py", label="🚀 Create an account", icon="✅")
    st.page_link("pages/Login.py", label="🔑 Already have an account? Log in", icon="➡️")

with col2:
    st.markdown(
        """
        <div class="tb-card">
            <div class="tb-title">How it works</div>
            <ol>
                <li>Create your profile & travel preferences</li>
                <li>Add an upcoming trip</li>
                <li>Get ranked buddy matches instantly</li>
                <li>Chat, connect, and travel together</li>
            </ol>
        </div>
        """,
        unsafe_allow_html=True,
    )

render_footer()
