"""
Login.py
--------
User login page with email/password authentication, "Remember Me", and a
"Forgot Password" placeholder flow.
"""

import streamlit as st

from database.database import init_db
from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from auth.auth import login_user, is_authenticated
from database import crud

st.set_page_config(page_title="Login | Travel Buddy Finder", page_icon="🔑", layout="centered")

if "db_initialized" not in st.session_state:
    init_db()
    st.session_state["db_initialized"] = True

inject_custom_css()
render_sidebar()
render_navbar("Login", "Welcome back, traveler!")

if is_authenticated():
    st.success("You are already logged in.")
    st.page_link("pages/Dashboard.py", label="Go to Dashboard", icon="➡️")
    render_footer()
    st.stop()

with st.container():
    st.markdown('<div class="tb-card">', unsafe_allow_html=True)

    with st.form("login_form", clear_on_submit=False):
        email = st.text_input("Email", placeholder="you@example.com")
        password = st.text_input("Password", type="password", placeholder="••••••••")
        remember_me = st.checkbox("Remember me", value=True)
        submitted = st.form_submit_button("Login", use_container_width=True)

        if submitted:
            if not email or not password:
                st.error("Please enter both email and password.")
            elif login_user(email, password):
                st.session_state["remember_me"] = remember_me
                st.success("Login successful! Redirecting to your dashboard...")
                st.switch_page("pages/Dashboard.py")
            else:
                st.error("Invalid email or password. Please try again.")

    st.markdown("</div>", unsafe_allow_html=True)

    with st.expander("Forgot your password?"):
        reset_email = st.text_input("Enter your account email to reset your password", key="reset_email")
        if st.button("Send Reset Instructions"):
            user = crud.get_user_by_email(reset_email) if reset_email else None
            if user:
                st.info(
                    "If this were a production deployment, a password reset link "
                    "would now be emailed to you. (Email delivery is not configured "
                    "in this demo environment.)"
                )
            else:
                st.warning("No account found with that email address.")

    st.markdown("Don't have an account?")
    st.page_link("pages/Register.py", label="Create one now", icon="📝")

render_footer()
