"""
Register.py
-----------
New user registration page with full field validation, password hashing,
and optional profile picture upload.
"""

import os
import uuid

import streamlit as st

from database.database import init_db
from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from auth.auth import register_user, is_authenticated
from utils.validators import (
    is_valid_email,
    is_valid_phone,
    is_strong_password,
    passwords_match,
    is_valid_age,
    is_valid_name,
)

st.set_page_config(page_title="Register | Travel Buddy Finder", page_icon="📝", layout="centered")

if "db_initialized" not in st.session_state:
    init_db()
    st.session_state["db_initialized"] = True

inject_custom_css()
render_sidebar()
render_navbar("Create Your Account", "Join thousands of travelers finding companions worldwide")

if is_authenticated():
    st.success("You are already logged in.")
    st.page_link("pages/Dashboard.py", label="Go to Dashboard", icon="➡️")
    render_footer()
    st.stop()

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "profile_photos")
os.makedirs(UPLOAD_DIR, exist_ok=True)


def save_profile_photo(uploaded_file) -> str:
    """Persist an uploaded profile photo to disk and return its relative path."""
    ext = os.path.splitext(uploaded_file.name)[1]
    filename = f"{uuid.uuid4().hex}{ext}"
    filepath = os.path.join(UPLOAD_DIR, filename)
    with open(filepath, "wb") as f:
        f.write(uploaded_file.getbuffer())
    return filepath


st.markdown('<div class="tb-card">', unsafe_allow_html=True)

with st.form("register_form"):
    col1, col2 = st.columns(2)
    with col1:
        name = st.text_input("Full Name *")
        email = st.text_input("Email *")
        phone = st.text_input("Phone Number")
        age = st.number_input("Age *", min_value=16, max_value=100, value=25)
    with col2:
        gender = st.selectbox("Gender *", ["Male", "Female", "Other", "Prefer not to say"])
        city = st.text_input("City *")
        country = st.text_input("Country *")
        profile_pic = st.file_uploader("Profile Picture", type=["png", "jpg", "jpeg"])

    password = st.text_input("Password *", type="password")
    confirm_password = st.text_input("Confirm Password *", type="password")

    agree = st.checkbox("I agree to the Terms of Service and Privacy Policy")
    submitted = st.form_submit_button("Create Account", use_container_width=True)

    if submitted:
        errors = []

        if not is_valid_name(name):
            errors.append("Please enter a valid full name.")
        if not is_valid_email(email):
            errors.append("Please enter a valid email address.")
        if not is_valid_phone(phone):
            errors.append("Please enter a valid phone number.")
        if not is_valid_age(int(age)):
            errors.append("Age must be between 16 and 100.")
        if not city.strip():
            errors.append("City is required.")
        if not country.strip():
            errors.append("Country is required.")

        password_issue = is_strong_password(password)
        if password_issue:
            errors.append(password_issue)
        if not passwords_match(password, confirm_password):
            errors.append("Passwords do not match.")
        if not agree:
            errors.append("You must agree to the Terms of Service to register.")

        if errors:
            for err in errors:
                st.error(err)
        else:
            photo_path = save_profile_photo(profile_pic) if profile_pic else None
            error_message = register_user(
                name=name,
                email=email,
                password=password,
                phone=phone,
                gender=gender,
                age=int(age),
                city=city,
                country=country,
                profile_photo=photo_path,
            )
            if error_message:
                st.error(error_message)
            else:
                st.success("Account created successfully! You can now log in.")
                st.page_link("pages/Login.py", label="Go to Login", icon="🔑")

st.markdown("</div>", unsafe_allow_html=True)

render_footer()
