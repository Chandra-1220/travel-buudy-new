"""
Notifications.py
----------------
Displays all notifications for the current user and allows marking them
as read.
"""

import streamlit as st

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from components.cards import notification_card
from auth.auth import require_login, get_current_user_id
from database import crud

st.set_page_config(page_title="Notifications | Travel Buddy Finder", page_icon="🔔", layout="wide")

inject_custom_css()
render_sidebar()
require_login()

user_id = get_current_user_id()

render_navbar("Notifications", "Stay up to date with your travel buddy activity")

filter_choice = st.radio("Show", ["All", "Unread Only"], horizontal=True)

notifications = crud.get_notifications(user_id, unread_only=(filter_choice == "Unread Only"))

if not notifications:
    st.info("You're all caught up! No notifications to show.")
else:
    for note in notifications:
        col1, col2 = st.columns([5, 1])
        with col1:
            notification_card(
                note.title, note.description or "", note.created_at.strftime("%b %d, %Y %H:%M"),
                unread=(note.status == "unread"),
            )
        with col2:
            if note.status == "unread":
                if st.button("Mark read", key=f"read_{note.id}"):
                    crud.mark_notification_read(note.id)
                    st.rerun()

render_footer()
