"""
Find_Buddy.py
-------------
Core buddy-matching page. Lets the user select one of their trips, then
runs the weighted compatibility algorithm against all other users' trips
and displays ranked match cards with a "Send Buddy Request" action.
Also includes a general search/filter view of all trips.
"""

import streamlit as st

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from components.cards import match_card, trip_card
from auth.auth import require_login, get_current_user_id
from database import crud
from utils.matching import find_matches
from utils.notifications import notify_buddy_request

st.set_page_config(page_title="Find a Buddy | Travel Buddy Finder", page_icon="🤝", layout="wide")

inject_custom_css()
render_sidebar()
require_login()

user_id = get_current_user_id()
user = crud.get_user_by_id(user_id)

render_navbar("Find a Travel Buddy", "AI-powered matches based on your trips and preferences")

tab_matches, tab_search = st.tabs(["🎯 Smart Matches", "🔍 Search All Trips"])

# ---------------------------------------------------------------------------
# TAB 1: Smart matching based on one of the user's own trips
# ---------------------------------------------------------------------------
with tab_matches:
    my_trips = crud.get_trips_by_user(user_id)

    if not my_trips:
        st.info("Create a trip first so we can find compatible buddies for it.")
        st.page_link("pages/Create_Trip.py", label="Create a Trip", icon="➕")
    else:
        trip_options = {f"{t.destination} ({t.start_date} - {t.end_date})": t for t in my_trips}
        selected_label = st.selectbox("Select one of your trips to find buddies for:", list(trip_options.keys()))
        selected_trip = trip_options[selected_label]

        all_other_trips = crud.get_all_trips(exclude_user_id=user_id)
        all_users = crud.get_all_users(exclude_id=user_id)
        users_by_id = {u.id: u for u in all_users}

        matches = find_matches(
            user_trip=selected_trip,
            user_interests=user.interests or "",
            candidate_trips=all_other_trips,
            candidate_users_by_id=users_by_id,
            exclude_user_id=user_id,
            top_n=20,
        )

        st.markdown(f"### {len(matches)} potential buddies found")

        if not matches:
            st.warning("No compatible trips found yet. Check back later as more travelers join!")

        for match in matches:
            with st.container():
                st.markdown('<div class="tb-card">', unsafe_allow_html=True)
                col1, col2 = st.columns([4, 1])
                with col1:
                    match_card(
                        name=match.user.name,
                        destination=match.trip.destination,
                        budget=match.trip.budget,
                        compatibility_score=match.compatibility_score,
                        common_interests=match.common_interests,
                    )
                with col2:
                    st.markdown("<br>", unsafe_allow_html=True)
                    if st.button("Send Request", key=f"req_{match.trip.id}_{match.user.id}"):
                        crud.create_buddy_request(sender=user_id, receiver=match.user.id, trip_id=match.trip.id)
                        notify_buddy_request(match.user.id, user.name)
                        st.success(f"Buddy request sent to {match.user.name}!")
                st.markdown("</div>", unsafe_allow_html=True)

# ---------------------------------------------------------------------------
# TAB 2: General search across all trips with filters
# ---------------------------------------------------------------------------
with tab_search:
    st.markdown("#### Filter Trips")
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        destination_filter = st.text_input("Destination contains", key="search_dest")
    with col2:
        min_budget = st.number_input("Min Budget", min_value=0.0, value=0.0, step=100.0, key="search_min_budget")
    with col3:
        max_budget = st.number_input("Max Budget", min_value=0.0, value=10000.0, step=100.0, key="search_max_budget")
    with col4:
        style_filter = st.selectbox(
            "Travel Style", ["Any", "Adventure", "Luxury", "Solo", "Backpacking", "Foodie", "Photography"],
            key="search_style",
        )

    results = crud.search_trips(
        destination=destination_filter or None,
        min_budget=min_budget or None,
        max_budget=max_budget or None,
        travel_style=None if style_filter == "Any" else style_filter,
    )
    results = [t for t in results if t.user_id != user_id]

    st.markdown(f"### {len(results)} trips match your filters")
    cols = st.columns(2)
    for i, trip in enumerate(results):
        owner = crud.get_user_by_id(trip.user_id)
        with cols[i % 2]:
            trip_card(trip.destination, trip.source, trip.start_date, trip.end_date, trip.budget, trip.travel_style)
            st.caption(f"Posted by {owner.name if owner else 'Unknown'}")
            if st.button(f"Send Buddy Request to {owner.name if owner else 'user'}", key=f"search_req_{trip.id}"):
                crud.create_buddy_request(sender=user_id, receiver=trip.user_id, trip_id=trip.id)
                notify_buddy_request(trip.user_id, user.name)
                st.success("Buddy request sent!")

render_footer()
