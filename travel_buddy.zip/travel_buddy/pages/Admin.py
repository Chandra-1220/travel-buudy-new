"""
Admin.py
--------
Admin-only dashboard: view and delete users/trips, and see platform-wide
analytics. Access is restricted via require_admin().
"""

import pandas as pd
import plotly.express as px
import streamlit as st

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from components.cards import stat_card
from auth.auth import require_admin
from database import crud

st.set_page_config(page_title="Admin | Travel Buddy Finder", page_icon="🛠️", layout="wide")

inject_custom_css()
render_sidebar()
require_admin()

render_navbar("Admin Dashboard", "Platform management and reporting")

all_users = crud.get_all_users()
all_trips = crud.get_all_trips()

col1, col2, col3, col4 = st.columns(4)
with col1:
    stat_card("Total Users", str(len(all_users)), "👥")
with col2:
    stat_card("Total Trips", str(len(all_trips)), "🧳")
with col3:
    admins = len([u for u in all_users if u.is_admin])
    stat_card("Admins", str(admins), "🛡️")
with col4:
    verified = len([u for u in all_users if u.verified])
    stat_card("Verified Users", str(verified), "✅")

tab_users, tab_trips, tab_reports = st.tabs(["👥 Users", "🧳 Trips", "📊 Platform Analytics"])

with tab_users:
    st.markdown("#### All Registered Users")
    for u in all_users:
        col1, col2, col3 = st.columns([3, 2, 1])
        with col1:
            badge = " 🛡️ Admin" if u.is_admin else ""
            st.markdown(f"**{u.name}**{badge}  \n{u.email}")
        with col2:
            st.markdown(f"📍 {u.city}, {u.country}")
        with col3:
            if not u.is_admin:
                if st.button("🗑️ Delete", key=f"admin_del_user_{u.id}"):
                    crud.delete_user(u.id)
                    st.success(f"Deleted user {u.name}.")
                    st.rerun()

with tab_trips:
    st.markdown("#### All Trips")
    for t in all_trips:
        owner = crud.get_user_by_id(t.user_id)
        col1, col2, col3 = st.columns([3, 2, 1])
        with col1:
            st.markdown(f"**{t.source} → {t.destination}**  \nBy {owner.name if owner else 'Unknown'}")
        with col2:
            st.markdown(f"🗓️ {t.start_date} to {t.end_date}  \n💰 ${t.budget:,.0f}")
        with col3:
            if st.button("🗑️ Delete", key=f"admin_del_trip_{t.id}"):
                crud.delete_trip(t.id)
                st.success("Trip deleted.")
                st.rerun()

with tab_reports:
    if not all_trips:
        st.info("No trip data available yet.")
    else:
        df = pd.DataFrame([
            {"destination": t.destination, "budget": t.budget, "style": t.travel_style or "Unspecified"}
            for t in all_trips
        ])

        col_a, col_b = st.columns(2)
        with col_a:
            st.markdown("#### Top Destinations Platform-Wide")
            dest_counts = df["destination"].value_counts().reset_index().head(10)
            dest_counts.columns = ["Destination", "Trips"]
            fig1 = px.bar(dest_counts, x="Destination", y="Trips", color_discrete_sequence=["#2E86AB"])
            fig1.update_layout(margin=dict(l=10, r=10, t=10, b=10), height=350)
            st.plotly_chart(fig1, use_container_width=True)

        with col_b:
            st.markdown("#### Travel Style Distribution")
            style_counts = df["style"].value_counts().reset_index()
            style_counts.columns = ["Style", "Count"]
            fig2 = px.pie(style_counts, names="Style", values="Count", hole=0.4)
            fig2.update_layout(margin=dict(l=10, r=10, t=10, b=10), height=350)
            st.plotly_chart(fig2, use_container_width=True)

render_footer()
