"""
Create_Trip.py
--------------
Form for creating a new trip, with an interactive Folium route map preview.
"""

from datetime import date, timedelta

import streamlit as st
from streamlit_folium import st_folium

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from auth.auth import require_login, get_current_user_id
from database import crud
from utils.validators import validate_trip_dates, sanitize_text
from utils.map_utils import build_route_map

st.set_page_config(page_title="Create Trip | Travel Buddy Finder", page_icon="➕", layout="wide")

inject_custom_css()
render_sidebar()
require_login()

user_id = get_current_user_id()

render_navbar("Plan a New Trip", "Tell us where you're headed and we'll find your buddies")

TRAVEL_STYLES = ["Adventure", "Luxury", "Solo", "Backpacking", "Foodie", "Photography"]
TRANSPORT_MODES = ["Flight", "Train", "Road Trip", "Cruise", "Bus"]
PURPOSES = ["Leisure", "Adventure", "Business + Leisure", "Backpacking", "Pilgrimage", "Study"]

col_form, col_map = st.columns([2, 1])

with col_form:
    st.markdown('<div class="tb-card">', unsafe_allow_html=True)
    with st.form("create_trip_form"):
        col1, col2 = st.columns(2)
        with col1:
            source = st.text_input("Source City *", placeholder="e.g. Hyderabad")
            start_date = st.date_input("Start Date *", value=date.today() + timedelta(days=7), min_value=date.today())
            budget = st.number_input("Budget (USD) *", min_value=50.0, max_value=100000.0, value=1000.0, step=50.0)
            transportation = st.selectbox("Transportation", TRANSPORT_MODES)
        with col2:
            destination = st.text_input("Destination City *", placeholder="e.g. Bali")
            end_date = st.date_input("End Date *", value=date.today() + timedelta(days=14), min_value=date.today())
            travel_style = st.selectbox("Travel Style", TRAVEL_STYLES)
            max_companions = st.slider("Maximum Companions", 1, 6, 2)

        purpose = st.selectbox("Purpose of Trip", PURPOSES)
        description = st.text_area("Trip Description", placeholder="Share what you're planning to do...", max_chars=800)

        submitted = st.form_submit_button("Create Trip", use_container_width=True)

        if submitted:
            errors = []
            if not source.strip():
                errors.append("Source city is required.")
            if not destination.strip():
                errors.append("Destination city is required.")

            date_error = validate_trip_dates(start_date, end_date)
            if date_error:
                errors.append(date_error)

            if errors:
                for err in errors:
                    st.error(err)
            else:
                trip_id = crud.create_trip(
                    user_id=user_id,
                    source=sanitize_text(source, 100),
                    destination=sanitize_text(destination, 100),
                    start_date=start_date,
                    end_date=end_date,
                    budget=float(budget),
                    transportation=transportation,
                    travel_style=travel_style,
                    purpose=purpose,
                    description=sanitize_text(description, 800),
                    max_companions=max_companions,
                )
                st.success(f"Trip to {destination} created successfully!")
                st.page_link("pages/Find_Buddy.py", label="Find travel buddies for this trip", icon="🤝")
    st.markdown("</div>", unsafe_allow_html=True)

with col_map:
    st.markdown("#### Route Preview")
    preview_source = source.strip() if source.strip() else "New York"
    preview_destination = destination.strip() if destination.strip() else "Paris"
    fmap = build_route_map(preview_source, preview_destination)
    st_folium(fmap, width=350, height=400)
    st.caption("Map updates once you enter recognized source/destination cities.")

render_footer()
