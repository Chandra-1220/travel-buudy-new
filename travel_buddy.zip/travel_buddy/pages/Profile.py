"""
Profile.py
----------
Editable user profile: photo, bio, languages, interests, budget preference,
and travel style.
"""

import os
import uuid

import streamlit as st

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from auth.auth import require_login, get_current_user_id
from database import crud
from utils.validators import is_valid_phone, sanitize_text

st.set_page_config(page_title="Profile | Travel Buddy Finder", page_icon="👤", layout="wide")

inject_custom_css()
render_sidebar()
require_login()

user_id = get_current_user_id()
user = crud.get_user_by_id(user_id)

render_navbar("My Profile", "Keep your details up to date for better matches")

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", "profile_photos")
os.makedirs(UPLOAD_DIR, exist_ok=True)

INTERESTS_OPTIONS = [
    "hiking", "photography", "food", "nightlife", "museums", "beaches",
    "adventure sports", "shopping", "history", "nature", "yoga", "diving",
    "trekking", "wildlife", "culture", "music festivals",
]
LANGUAGE_OPTIONS = ["English", "Spanish", "French", "German", "Hindi", "Mandarin", "Japanese", "Arabic"]
TRAVEL_STYLES = ["Adventure", "Luxury", "Solo", "Backpacking", "Foodie", "Photography"]

col_photo, col_form = st.columns([1, 3])

with col_photo:
    if user.profile_photo and os.path.exists(user.profile_photo):
        st.image(user.profile_photo, width=180)
    else:
        st.image(f"https://api.dicebear.com/7.x/initials/svg?seed={user.name.replace(' ', '')}", width=180)
    new_photo = st.file_uploader("Update profile picture", type=["png", "jpg", "jpeg"])

with col_form:
    st.markdown('<div class="tb-card">', unsafe_allow_html=True)
    with st.form("profile_form"):
        col1, col2 = st.columns(2)
        with col1:
            name = st.text_input("Full Name", value=user.name)
            phone = st.text_input("Phone", value=user.phone or "")
            city = st.text_input("City", value=user.city or "")
        with col2:
            country = st.text_input("Country", value=user.country or "")
            budget_pref = st.selectbox(
                "Budget Preference", ["Low", "Medium", "High"],
                index=["Low", "Medium", "High"].index(user.budget_preference) if user.budget_preference in ["Low", "Medium", "High"] else 1,
            )
            travel_style = st.selectbox(
                "Preferred Travel Style", TRAVEL_STYLES,
                index=TRAVEL_STYLES.index(user.travel_style) if user.travel_style in TRAVEL_STYLES else 0,
            )

        bio = st.text_area("Bio", value=user.bio or "", max_chars=500)

        current_languages = [l.strip() for l in (user.languages or "").split(",") if l.strip()]
        languages = st.multiselect("Languages Spoken", LANGUAGE_OPTIONS, default=current_languages)

        current_interests = [i.strip() for i in (user.interests or "").split(",") if i.strip()]
        interests = st.multiselect("Travel Interests", INTERESTS_OPTIONS, default=current_interests)

        submitted = st.form_submit_button("Save Changes", use_container_width=True)

        if submitted:
            if phone and not is_valid_phone(phone):
                st.error("Please enter a valid phone number.")
            else:
                photo_path = user.profile_photo
                if new_photo is not None:
                    ext = os.path.splitext(new_photo.name)[1]
                    filename = f"{uuid.uuid4().hex}{ext}"
                    photo_path = os.path.join(UPLOAD_DIR, filename)
                    with open(photo_path, "wb") as f:
                        f.write(new_photo.getbuffer())

                crud.update_user(
                    user_id,
                    name=sanitize_text(name, 100),
                    phone=phone,
                    city=sanitize_text(city, 100),
                    country=sanitize_text(country, 100),
                    bio=sanitize_text(bio, 500),
                    languages=", ".join(languages),
                    interests=", ".join(interests),
                    budget_preference=budget_pref,
                    travel_style=travel_style,
                    profile_photo=photo_path,
                )
                st.success("Profile updated successfully!")
                st.session_state["user_name"] = name
                st.rerun()
    st.markdown("</div>", unsafe_allow_html=True)

render_footer()
