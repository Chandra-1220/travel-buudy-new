"""
Settings.py
-----------
Account settings: change password, theme preference, and account deletion.
"""

import streamlit as st

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from auth.auth import require_login, get_current_user_id, logout_user
from auth.hash import hash_password, verify_password
from database import crud
from utils.validators import is_strong_password, passwords_match

st.set_page_config(page_title="Settings | Travel Buddy Finder", page_icon="⚙️", layout="centered")

inject_custom_css()
render_sidebar()
require_login()

user_id = get_current_user_id()
user = crud.get_user_by_id(user_id)

render_navbar("Settings", "Manage your account preferences")

st.markdown("### 🔒 Change Password")
with st.form("change_password_form"):
    current_password = st.text_input("Current Password", type="password")
    new_password = st.text_input("New Password", type="password")
    confirm_new_password = st.text_input("Confirm New Password", type="password")
    submitted = st.form_submit_button("Update Password")

    if submitted:
        if not verify_password(current_password, user.password):
            st.error("Current password is incorrect.")
        else:
            issue = is_strong_password(new_password)
            if issue:
                st.error(issue)
            elif not passwords_match(new_password, confirm_new_password):
                st.error("New passwords do not match.")
            else:
                crud.update_user(user_id, password=hash_password(new_password))
                st.success("Password updated successfully!")

st.markdown("### 🎨 Appearance")
mode = st.radio("Theme", ["Light", "Dark"], index=0 if st.session_state.get("theme_mode", "light") == "light" else 1, horizontal=True)
if st.button("Apply Theme"):
    st.session_state["theme_mode"] = mode.lower()
    st.rerun()

st.markdown("### ⚠️ Danger Zone")
with st.expander("Delete My Account"):
    st.warning("This action is permanent and cannot be undone.")
    confirm_delete = st.text_input("Type DELETE to confirm")
    if st.button("Delete Account", type="primary"):
        if confirm_delete == "DELETE":
            crud.delete_user(user_id)
            logout_user()
            st.success("Your account has been deleted.")
            st.switch_page("app.py")
        else:
            st.error("Please type DELETE to confirm.")

render_footer()
