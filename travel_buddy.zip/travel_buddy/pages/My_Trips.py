"""
My_Trips.py
-----------
Manage the current user's trips: view, and delete. Also shows buddy
requests (sent/received) associated with each trip.
"""

import streamlit as st

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from components.cards import trip_card
from auth.auth import require_login, get_current_user_id
from database import crud
from utils.notifications import notify_request_accepted, notify_request_rejected

st.set_page_config(page_title="My Trips | Travel Buddy Finder", page_icon="🧳", layout="wide")

inject_custom_css()
render_sidebar()
require_login()

user_id = get_current_user_id()
user = crud.get_user_by_id(user_id)

render_navbar("My Trips", "Manage your travel plans and buddy requests")

tab_trips, tab_requests = st.tabs(["🗺️ My Trips", "📨 Buddy Requests"])

with tab_trips:
    trips = crud.get_trips_by_user(user_id)
    if not trips:
        st.info("You haven't created any trips yet.")
        st.page_link("pages/Create_Trip.py", label="Create your first trip", icon="➕")
    else:
        for trip in trips:
            col1, col2 = st.columns([5, 1])
            with col1:
                trip_card(trip.destination, trip.source, trip.start_date, trip.end_date, trip.budget, trip.travel_style)
                if trip.description:
                    st.caption(trip.description)
            with col2:
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button("🗑️ Delete", key=f"del_trip_{trip.id}"):
                    crud.delete_trip(trip.id)
                    st.success("Trip deleted.")
                    st.rerun()

with tab_requests:
    st.markdown("#### Incoming Requests")
    received = crud.get_requests_for_user(user_id, status="pending")
    if not received:
        st.info("No pending requests.")
    for req in received:
        sender = crud.get_user_by_id(req.sender)
        col1, col2, col3 = st.columns([3, 1, 1])
        with col1:
            st.markdown(f"**{sender.name if sender else 'Unknown'}** wants to travel with you.")
        with col2:
            if st.button("✅ Accept", key=f"accept_{req.id}"):
                crud.update_request_status(req.id, "accepted")
                notify_request_accepted(req.sender, user.name)
                st.success("Request accepted!")
                st.rerun()
        with col3:
            if st.button("❌ Reject", key=f"reject_{req.id}"):
                crud.update_request_status(req.id, "rejected")
                notify_request_rejected(req.sender, user.name)
                st.warning("Request rejected.")
                st.rerun()

    st.divider()
    st.markdown("#### Sent Requests")
    sent = crud.get_sent_requests(user_id)
    if not sent:
        st.info("You haven't sent any requests yet.")
    for req in sent:
        receiver = crud.get_user_by_id(req.receiver)
        status_emoji = {"pending": "⏳", "accepted": "✅", "rejected": "❌", "cancelled": "🚫"}.get(req.status, "•")
        col1, col2 = st.columns([4, 1])
        with col1:
            st.markdown(f"{status_emoji} Request to **{receiver.name if receiver else 'Unknown'}** — *{req.status}*")
        with col2:
            if req.status == "pending":
                if st.button("Cancel", key=f"cancel_{req.id}"):
                    crud.update_request_status(req.id, "cancelled")
                    st.info("Request cancelled.")
                    st.rerun()

render_footer()
