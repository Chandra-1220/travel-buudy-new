"""
Dashboard.py
------------
Main authenticated landing page: welcome card, upcoming trips, suggested
buddies, notifications preview, and travel statistics charts.
"""

from datetime import date

import streamlit as st
import plotly.express as px
import pandas as pd

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from components.cards import stat_card, trip_card, notification_card
from auth.auth import require_login, get_current_user_id
from database import crud
from utils.recommendation import recommend_similar_users

st.set_page_config(page_title="Dashboard | Travel Buddy Finder", page_icon="🏠", layout="wide")

inject_custom_css()
render_sidebar()
require_login()

user_id = get_current_user_id()
user = crud.get_user_by_id(user_id)

render_navbar("Dashboard", f"Welcome back, {user.name}! ✈️")

# --- Welcome + quick stats -------------------------------------------------
trips = crud.get_trips_by_user(user_id)
upcoming_trips = [t for t in trips if t.start_date >= date.today()]
sent_requests = crud.get_sent_requests(user_id)
received_requests = crud.get_requests_for_user(user_id)
accepted_count = len([r for r in sent_requests + received_requests if r.status == "accepted"])
avg_rating = crud.get_average_rating(user_id)

col1, col2, col3, col4 = st.columns(4)
with col1:
    stat_card("Total Trips", str(len(trips)), "🧳")
with col2:
    stat_card("Upcoming Trips", str(len(upcoming_trips)), "🗓️")
with col3:
    stat_card("Buddy Matches", str(accepted_count), "🤝")
with col4:
    stat_card("Avg. Rating", f"{avg_rating} ⭐" if avg_rating else "No ratings yet", "⭐")

st.markdown("### 🗺️ Upcoming Trips")
if upcoming_trips:
    cols = st.columns(2)
    for i, trip in enumerate(upcoming_trips[:4]):
        with cols[i % 2]:
            trip_card(trip.destination, trip.source, trip.start_date, trip.end_date, trip.budget, trip.travel_style)
else:
    st.info("You have no upcoming trips yet.")
    st.page_link("pages/Create_Trip.py", label="Plan your first trip", icon="➕")

st.markdown("### 🤝 Suggested Buddies For You")
all_users = crud.get_all_users(exclude_id=user_id)
recommendations = recommend_similar_users(user, all_users, top_n=4)
if recommendations:
    cols = st.columns(4)
    for i, (candidate, score) in enumerate(recommendations):
        with cols[i % 4]:
            st.markdown(
                f"""
                <div class="tb-card" style="text-align:center;">
                    <div class="tb-title">{candidate.name}</div>
                    <div class="tb-subtitle">📍 {candidate.city}, {candidate.country}</div>
                    <div class="tb-score-ring">{score}% similar</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
else:
    st.info("Add more interests to your profile to get better buddy suggestions.")

col_notif, col_chart = st.columns([1, 1])

with col_notif:
    st.markdown("### 🔔 Recent Notifications")
    notifications = crud.get_notifications(user_id)[:5]
    if notifications:
        for note in notifications:
            notification_card(
                note.title, note.description or "", note.created_at.strftime("%b %d, %Y %H:%M"),
                unread=(note.status == "unread"),
            )
    else:
        st.info("No notifications yet.")

with col_chart:
    st.markdown("### 📊 Your Travel Style Mix")
    if trips:
        df = pd.DataFrame([{"style": t.travel_style or "Unspecified"} for t in trips])
        counts = df["style"].value_counts().reset_index()
        counts.columns = ["Travel Style", "Count"]
        fig = px.pie(counts, names="Travel Style", values="Count", hole=0.45,
                     color_discrete_sequence=px.colors.sequential.Teal)
        fig.update_layout(margin=dict(l=10, r=10, t=10, b=10), height=320)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Create a trip to see your travel style breakdown.")

render_footer()
