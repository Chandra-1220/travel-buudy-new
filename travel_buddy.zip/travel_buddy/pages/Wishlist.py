"""
Wishlist.py
-----------
Lets a user save and manage a list of destinations they dream of visiting,
displayed alongside a Folium map of all saved spots.
"""

import streamlit as st
from streamlit_folium import st_folium

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from auth.auth import require_login, get_current_user_id
from database import crud
from utils.map_utils import build_destinations_map, CITY_COORDINATES

st.set_page_config(page_title="Wishlist | Travel Buddy Finder", page_icon="💖", layout="wide")

inject_custom_css()
render_sidebar()
require_login()

user_id = get_current_user_id()

render_navbar("Wishlist", "Dream destinations you want to visit someday")

col_form, _ = st.columns([2, 1])
with col_form:
    with st.form("add_wishlist_form", clear_on_submit=True):
        destination = st.selectbox("Add a destination", sorted(c.title() for c in CITY_COORDINATES.keys()))
        add = st.form_submit_button("➕ Add to Wishlist")
        if add:
            crud.add_to_wishlist(user_id, destination)
            st.success(f"{destination} added to your wishlist!")
            st.rerun()

wishlist_items = crud.get_wishlist(user_id)

col_list, col_map = st.columns([1, 2])

with col_list:
    st.markdown("#### Your Saved Destinations")
    if not wishlist_items:
        st.info("Your wishlist is empty. Add a destination above!")
    else:
        for item in wishlist_items:
            col1, col2 = st.columns([3, 1])
            with col1:
                st.markdown(f"📍 **{item.destination}**")
            with col2:
                if st.button("Remove", key=f"remove_{item.id}"):
                    crud.remove_from_wishlist(item.id)
                    st.rerun()

with col_map:
    st.markdown("#### Wishlist Map")
    fmap = build_destinations_map([item.destination for item in wishlist_items])
    st_folium(fmap, width=700, height=420)

render_footer()
