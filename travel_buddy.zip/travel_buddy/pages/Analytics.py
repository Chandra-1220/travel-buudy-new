"""
Analytics.py
------------
Personal travel analytics dashboard built with Plotly: total trips,
matches, average budget, favorite destination, monthly trip trend,
travel style distribution, and destination frequency.
"""

import pandas as pd
import plotly.express as px
import streamlit as st

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from components.cards import stat_card
from auth.auth import require_login, get_current_user_id
from database import crud

st.set_page_config(page_title="Analytics | Travel Buddy Finder", page_icon="📊", layout="wide")

inject_custom_css()
render_sidebar()
require_login()

user_id = get_current_user_id()

render_navbar("Travel Analytics", "Insights into your travel habits")

trips = crud.get_trips_by_user(user_id)
requests = crud.get_sent_requests(user_id) + crud.get_requests_for_user(user_id)
matches = len([r for r in requests if r.status == "accepted"])

if not trips:
    st.info("Create at least one trip to unlock your personal analytics.")
    st.page_link("pages/Create_Trip.py", label="Create a Trip", icon="➕")
    render_footer()
    st.stop()

df = pd.DataFrame([
    {
        "destination": t.destination,
        "budget": t.budget,
        "travel_style": t.travel_style or "Unspecified",
        "start_date": t.start_date,
        "month": t.start_date.strftime("%b %Y"),
    }
    for t in trips
])

favorite_destination = df["destination"].value_counts().idxmax()

col1, col2, col3, col4 = st.columns(4)
with col1:
    stat_card("Total Trips", str(len(trips)), "🧳")
with col2:
    stat_card("Total Matches", str(matches), "🤝")
with col3:
    stat_card("Avg. Budget", f"${df['budget'].mean():,.0f}", "💰")
with col4:
    stat_card("Favorite Destination", favorite_destination, "📍")

col_a, col_b = st.columns(2)

with col_a:
    st.markdown("#### Monthly Trip Trend")
    monthly = df.groupby("month").size().reset_index(name="trips")
    fig1 = px.bar(monthly, x="month", y="trips", color_discrete_sequence=["#2E86AB"])
    fig1.update_layout(margin=dict(l=10, r=10, t=10, b=10), height=320)
    st.plotly_chart(fig1, use_container_width=True)

with col_b:
    st.markdown("#### Travel Style Distribution")
    style_counts = df["travel_style"].value_counts().reset_index()
    style_counts.columns = ["Travel Style", "Count"]
    fig2 = px.pie(style_counts, names="Travel Style", values="Count", hole=0.4,
                  color_discrete_sequence=px.colors.sequential.Sunset)
    fig2.update_layout(margin=dict(l=10, r=10, t=10, b=10), height=320)
    st.plotly_chart(fig2, use_container_width=True)

st.markdown("#### Destination Frequency")
dest_counts = df["destination"].value_counts().reset_index()
dest_counts.columns = ["Destination", "Visits Planned"]
fig3 = px.bar(dest_counts, x="Destination", y="Visits Planned", color_discrete_sequence=["#3FBF7F"])
fig3.update_layout(margin=dict(l=10, r=10, t=10, b=10), height=350)
st.plotly_chart(fig3, use_container_width=True)

render_footer()
