"""
Chat.py
-------
Simple messaging system between matched travel buddies. Shows a list of
conversation partners on the left and the active thread on the right.
"""

import streamlit as st

from components.theme import inject_custom_css
from components.sidebar import render_sidebar
from components.navbar import render_navbar
from components.footer import render_footer
from auth.auth import require_login, get_current_user_id
from database import crud
from utils.notifications import notify_new_message

st.set_page_config(page_title="Chat | Travel Buddy Finder", page_icon="💬", layout="wide")

inject_custom_css()
render_sidebar()
require_login()

user_id = get_current_user_id()
user = crud.get_user_by_id(user_id)

render_navbar("Chat", "Message your travel buddies")

# Build the list of conversation partners from message history plus
# accepted buddy requests (so a brand-new match can be messaged immediately).
partner_ids = set(crud.get_conversation_partners(user_id))
for req in crud.get_sent_requests(user_id) + crud.get_requests_for_user(user_id):
    if req.status == "accepted":
        partner_ids.add(req.receiver if req.sender == user_id else req.sender)
partner_ids.discard(user_id)

col_list, col_thread = st.columns([1, 3])

with col_list:
    st.markdown("#### Conversations")
    if not partner_ids:
        st.info("No conversations yet. Match with a buddy first!")
    else:
        for pid in partner_ids:
            partner = crud.get_user_by_id(pid)
            if partner and st.button(f"👤 {partner.name}", key=f"chat_partner_{pid}", use_container_width=True):
                st.session_state["active_chat_partner"] = pid

with col_thread:
    active_partner_id = st.session_state.get("active_chat_partner")

    if not active_partner_id or active_partner_id not in partner_ids:
        st.info("Select a conversation from the left to start chatting.")
    else:
        partner = crud.get_user_by_id(active_partner_id)
        st.markdown(f"#### 💬 Conversation with {partner.name}")

        messages = crud.get_conversation(user_id, active_partner_id)

        chat_container = st.container(height=420)
        with chat_container:
            if not messages:
                st.caption("No messages yet. Say hello!")
            for msg in messages:
                is_me = msg.sender == user_id
                align = "right" if is_me else "left"
                bubble_color = "#2E86AB" if is_me else "#E5E7EB"
                text_color = "white" if is_me else "#1F2933"
                sender_label = "You" if is_me else partner.name
                st.markdown(
                    f"""
                    <div style="text-align:{align}; margin-bottom:0.5rem;">
                        <span style="
                            display:inline-block;
                            background:{bubble_color};
                            color:{text_color};
                            padding:0.5rem 0.9rem;
                            border-radius:14px;
                            max-width:70%;
                        ">
                            <b>{sender_label}:</b> {msg.message}
                        </span>
                        <div style="font-size:0.7rem; color:#9AA5B1;">
                            {msg.timestamp.strftime('%b %d, %H:%M')}
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

        with st.form("send_message_form", clear_on_submit=True):
            new_message = st.text_input("Type a message (emojis welcome 😊🌍✈️)", key="new_message_input")
            sent = st.form_submit_button("Send")
            if sent and new_message.strip():
                crud.send_message(user_id, active_partner_id, new_message.strip())
                notify_new_message(active_partner_id, user.name)
                st.rerun()

render_footer()
